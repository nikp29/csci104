#include <iostream>

int main() {

    std::cout << "                  .\"-,.__   " << std::endl;
    std::cout << "                  `.     `.  ,   " << std::endl;
    std::cout << "               .--'  .._,'\"-' `.   " << std::endl;
    std::cout << "              .    .'         `'   " << std::endl;
    std::cout << "              `.   /          ,'   " << std::endl;
    std::cout << "                `  '--.   ,-\"'  " << std::endl;
    std::cout << "                 `\"`   |  \\   " << std::endl;
    std::cout << "                    -. \\, |   " << std::endl;
    std::cout << "                     `--Y.'      ___.   " << std::endl;
    std::cout << "                          \\     L._, \\   " << std::endl;
    std::cout << "                _.,        `.   <  <\\                _  " << std::endl;
    std::cout << "              ,' '           `, `.   | \\            ( `  " << std::endl;
    std::cout << "           ../, `.            `  |    .\\`.           \\ \\_  " << std::endl;
    std::cout << "          ,' ,..  .           _.,'    ||\\l            )  '\".  " << std::endl;
    std::cout << "         , ,'   \\           ,'.-.`-._,'  |           .  _._`.  " << std::endl;
    std::cout << "       ,' /      \\ \\        `' ' `--/   | \\          / /   ..\\  " << std::endl;
    std::cout << "     .'  /        \\ .         |\\__ - _ ,'` `        / /     `.`.  " << std::endl;
    std::cout << "     |  '          ..         `-...-\"  |  `-'      / /        . `.  " << std::endl;
    std::cout << "     | /           |L__           |    |          / /          `. `.  " << std::endl;
    std::cout << "    , /            .   .          |    |         / /             ` `  " << std::endl;
    std::cout << "   / /          ,. ,`._ `-_       |    |  _   ,-' /               ` \\  " << std::endl;
    std::cout << "  / .           \"`_/. `-_ \\_,.  ,'    +-' `-'  _,        ..,-.    \\`.  " << std::endl;
    std::cout << "   '         .-f    ,'   `    '.       \\__.---'     _   .'   '     \\ \\  " << std::endl;
    std::cout << " ' /          `.'    l     .' /          \\..      ,_|/   `.  ,'`     L`  " << std::endl;
    std::cout << " |'      _.-\"\"` `.    \\ _,'  `            \\ `.___`.'\"`-.  , |   |    | \\  " << std::endl;
    std::cout << " ||    ,'      `. `.   '       _,...._        `  |    `/ '  |   '     .|  " << std::endl;
    std::cout << " ||  ,'          `. ;.,.---' ,'       `.   `.. `-'  .-' /_ .'    ;_   ||  " << std::endl;
    std::cout << " || '              V      / /           `   | `   ,'   ,' '.    !  `. ||  " << std::endl;
    std::cout << " ||/            _,-------7 '              . |  `-'    l         /    `||  " << std::endl;
    std::cout << "  |          ,' .-   ,' ||               | .-.        `.      .'     ||  " << std::endl;
    std::cout << "  `'        ,'    `\".'    |               |    `.        '. -.'       `'  " << std::endl;
    std::cout << "           /      ,'      |               |,'    \\-.._,.'/'  " << std::endl;
    std::cout << "           .     /        .               .       \\    .''  " << std::endl;
    std::cout << "         .`.    |         `.             /         :_,'.'  " << std::endl;
    std::cout << "           \\ `...\\   _     ,'-.        .'         /_.-'  " << std::endl;
    std::cout << "            `-.__ `,  `'   .  _.>----''.  _  __  /  " << std::endl;
    std::cout << "                 .'        /\"'          |  \"'   '_  " << std::endl;
    std::cout << "                /_|.-'\\ ,\".             '.'`__'-( \\  " << std::endl;
    std::cout << "                  / ,\"'\"\\,'               `/  `-.|\" mh  " << std::endl;

    std::cout << std::endl << " I AM CHARIZARD. HEAR ME ROAR. :W " << std::endl;

    return 0;
}

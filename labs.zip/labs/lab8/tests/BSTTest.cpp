#include "gtest/gtest.h"
#include "../bst.h"

#include <vector>
#include <iostream>

using namespace std;


TEST(RangeSumTest, Empty) {
    EXPECT_EQ(0, rangeSum(NULL, 0, 0));
}

TEST(RangeSumTest, Simple) {
    //leaf nodes
    //1 3 5 7
    Node n1(1);
    Node n3(3);
    Node n5(5);
    Node n7(7);

    //2 6
    Node n2(&n1, &n3, 2);
    Node n6(&n5, &n7, 6);

    //4
    Node n4(&n2, &n6, 4);

    EXPECT_EQ(rangeSum(&n4, 1, 3), 6);
    //inOrder(&n4);

}

TEST(RangeSumTest, InvalidRange) {
    //leaf nodes
    //1 3 5 7
    Node n1(1);
    Node n3(3);
    Node n5(5);
    Node n7(7);

    //2 6
    Node n2(&n1, &n3, 2);
    Node n6(&n5, &n7, 6);

    //4
    Node n4(&n2, &n6, 4);

    EXPECT_EQ(rangeSum(&n4, 3, 1), 0);
     //inOrder(&n4);

}

TEST(RangeSumTest, OutOfRange) {
    //leaf nodes
    //1 3 5 7
    Node n1(1);
    Node n3(3);
    Node n5(5);
    Node n7(7);

    //2 6
    Node n2(&n1, &n3, 2);
    Node n6(&n5, &n7, 6);

    //4
    Node n4(&n2, &n6, 4);

    EXPECT_EQ(rangeSum(&n4, 20, 25), 0);
     //inOrder(&n4);

}

TEST(RangeSumTest, AnotherSimple) {
    //leaf nodes
    //2 7 14 20
    Node n2(2);
    Node n7(7);
    Node n14(14);
    Node n20(20);

    //5 12 16
    Node n5(nullptr, &n7, 5);
    Node n12(nullptr, &n14, 12);
    Node n16(nullptr, &n20, 16);

    //4 15
    Node n4(&n2, &n5, 4);
    Node n15(&n12, &n16, 15);

    //10
    Node n10(&n4, &n15, 10);

    EXPECT_EQ(rangeSum(&n10, 7, 14), 43);
    // inOrder(&n10);

}

TEST(RangeSumTest, WholeTree) {
    //leaf nodes
    //2 7 12 15
    Node n2(2);
    Node n7(7);
    Node n12(12);
    Node n15(15);
    Node n20(20);

    //4 14
    Node n4(&n2, nullptr, 4);
    Node n14(&n12, &n15, 14);

    //10
    Node n10(&n7, &n14, 10);

    //16
    Node n16(&n10, &n20, 16);

    //5
    Node n5(&n4, &n16, 5);

    EXPECT_EQ(rangeSum(&n5, 2, 20), 105);
    // inOrder(&n5);

}

TEST(RangeSumTest, WholeTreeWideRange) {
    //leaf nodes
    //16, 45
    Node n16(16);
    Node n45(45);

    //43
    Node n43(nullptr, &n45, 43);

    //34
    Node n34(nullptr, &n43, 34);

    //49
    Node n49(&n34, nullptr, 49);

    //23
    Node n23(&n16, &n49, 23);

    //12
    Node n12(nullptr, &n23, 12);

    EXPECT_EQ(rangeSum(&n12, 0, 1000), 222);
    // inOrder(&n12);

}